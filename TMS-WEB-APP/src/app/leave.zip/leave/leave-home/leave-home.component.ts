import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-home',
  templateUrl: './leave-home.component.html'
})
export class LeaveHomeComponent {}

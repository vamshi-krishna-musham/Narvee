#!/bin/bash
java -jar /home/ec2-user/eureka-server.jar > /home/ec2-user/eureka-server.log 2>&1 &

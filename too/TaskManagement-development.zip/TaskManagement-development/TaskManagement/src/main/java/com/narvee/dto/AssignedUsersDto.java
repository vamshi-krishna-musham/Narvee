package com.narvee.dto;


public interface AssignedUsersDto {
	
     Long getuserId();
     String getfullName();
}

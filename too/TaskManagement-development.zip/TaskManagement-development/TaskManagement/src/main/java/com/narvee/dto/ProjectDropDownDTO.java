package com.narvee.dto;

public interface ProjectDropDownDTO {
	
	public Long getPid();
	public String getProjectid();
	public String getProjectname();
}

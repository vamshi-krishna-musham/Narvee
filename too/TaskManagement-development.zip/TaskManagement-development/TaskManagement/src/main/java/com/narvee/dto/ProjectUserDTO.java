package com.narvee.dto;

public interface ProjectUserDTO {

	public Long getprojectid();
	public String getprojectname();
	public String getprojectdescription();
	public String getaddedby();

}

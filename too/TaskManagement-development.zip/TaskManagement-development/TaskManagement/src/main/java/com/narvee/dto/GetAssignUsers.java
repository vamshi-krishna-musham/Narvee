package com.narvee.dto;

public interface GetAssignUsers {
	public Long getUserid();
	public Long getTaskid();
	public Long getAssignid();
	public boolean getCompleted();
}

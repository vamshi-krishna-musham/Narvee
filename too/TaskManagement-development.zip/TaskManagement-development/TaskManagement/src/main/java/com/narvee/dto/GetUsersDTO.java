package com.narvee.dto;


public interface GetUsersDTO {
	
	public Long getUserid();
	public String getFullname();
	public String getPseudoname();
	public String getEmail();
	public String getCreatedby();
	public String getTaskid();
	public String getProjectname();
	public String getTaskname();
	public String getTicketid();
	public String getUpdatedby();
	public String getCemail();
	public String getStart_date();
	public String getTarget_date();
	public byte[] getProfile();
	public byte[] getpCprofile();
 	
	
}

export class Project {
    public pid!: number | string;
    public projectId: any;
    public projectName!: string;
    public description!: string;
    public department!: string;
    public assignedto!: any
    public status!: string;
    public addedBy: any;
    public updatedBy: any;
  }
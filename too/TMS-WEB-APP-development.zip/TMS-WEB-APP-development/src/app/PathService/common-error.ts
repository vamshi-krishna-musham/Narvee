export class commonerror{
    constructor(public message: string){
    }
  }
package com.narvee.ats.auth.dto;


public interface AssociatedCompanyDetailsDTO {

	public Long getA_cid();

	public String getCmpname();

	public String getAssocitedname();
	
	public Long getId();

}

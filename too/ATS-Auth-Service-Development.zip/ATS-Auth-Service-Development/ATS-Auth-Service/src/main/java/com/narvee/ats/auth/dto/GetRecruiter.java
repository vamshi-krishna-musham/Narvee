package com.narvee.ats.auth.dto;

public interface GetRecruiter {

	public long getUserid();

	public String getFullname();

	public String getPseudoname();

}

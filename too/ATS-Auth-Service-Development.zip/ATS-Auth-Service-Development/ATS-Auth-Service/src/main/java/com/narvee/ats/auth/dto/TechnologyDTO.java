package com.narvee.ats.auth.dto;

public interface TechnologyDTO {

	public Long getId();

	public String getTechnologyarea();

	public String Listofkeyword();

}

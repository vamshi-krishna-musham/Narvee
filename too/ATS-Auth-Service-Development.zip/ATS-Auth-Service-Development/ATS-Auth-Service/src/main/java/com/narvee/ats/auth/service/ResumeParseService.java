package com.narvee.ats.auth.service;

public interface ResumeParseService {

	
	public String parseResume(String resumeText);
}

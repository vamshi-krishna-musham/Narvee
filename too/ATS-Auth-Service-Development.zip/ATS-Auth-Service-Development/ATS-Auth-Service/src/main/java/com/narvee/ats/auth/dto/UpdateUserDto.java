package com.narvee.ats.auth.dto;

public interface UpdateUserDto {
	
	public Long getUserid();
	public String getFullname();
	public String getEmail();
	public String getPersonalcontactnumber();
	public String getCompanycontactnumber();
	public String getDesignation();
	public String getAlternatenumber();
}

package com.narvee.ats.auth.dto;

public interface EmpHierarchy {
	// u.pseudoname, u.,u.,u.email,u., u., um.pseudoname AS ,utl.pseudoname AS
	// ,u.userid AS teamleaduserid
	public String getPseudoname();

	//public String getDesignation();

	public String getDepartment();

	//public String getIsteamlead();

	//public String getIsmanager();

	public String getManagername();

	public String getTeamleadname();

	public String getUserid();

}

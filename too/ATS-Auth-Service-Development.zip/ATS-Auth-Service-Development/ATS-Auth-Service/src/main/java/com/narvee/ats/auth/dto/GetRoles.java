package com.narvee.ats.auth.dto;

public interface GetRoles {
	public Long getRoleid();
	public String getRolename();
}

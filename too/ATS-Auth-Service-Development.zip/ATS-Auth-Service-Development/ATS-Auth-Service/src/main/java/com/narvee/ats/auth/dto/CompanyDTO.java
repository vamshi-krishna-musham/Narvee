package com.narvee.ats.auth.dto;

public interface CompanyDTO {

	public Long getCompanyid();

	public String getCompanyname();

	public String getCreateddate();

	public String getDescription();

	public Long getUpdatedby();

	public Long getAddedby();

	public String getUpdateddate();

	public String getPseudoname();

	public String getDomain();

	public String getCode();

}

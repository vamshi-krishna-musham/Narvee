package com.narvee.ats.auth.dto;

public interface UserDTO {

	public Long getUserid();

	public String getFullname();

	public String getPseudoname();
	
	public String getRole();
	
	public Long getTeamlead();

}

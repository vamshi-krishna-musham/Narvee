package com.narvee.ats.auth.dto;

public interface TechAndSupportDTO {
	public String getName();

	public String getExperience();

	public String getTechnologyarea();

	public String getSkills();

	public String getEmail();

	public String getMobile();

	public String getSecond_mobile();

	public String getId();

}

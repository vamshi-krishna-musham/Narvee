package com.narvee.ats.auth.tms.dto;

public interface AllTmsUsers {
	
public Long getuserId();
public String getuserFullName();
public String getemail();
public String getposition();
public String getphoneNumber();
public String getuserRole();
public String getadminFullName();
public String getaddeByFullName();
public String getRoleName();
public String getorganisation_email();
public String getorganisation_name();
public String getcompany_domain();
public byte[] getprofile_photo();
public String getindustry();




 

}

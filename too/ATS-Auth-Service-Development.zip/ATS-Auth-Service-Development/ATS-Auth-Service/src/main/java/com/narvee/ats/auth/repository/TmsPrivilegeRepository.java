package com.narvee.ats.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.narvee.ats.auth.entity.TmsPrivilege;

public interface TmsPrivilegeRepository extends JpaRepository<TmsPrivilege, Long> {

}
